<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="ui/AboutDialog.ui" line="17"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/AboutDialog.ui" line="82"/>
        <source>&lt;table&gt;					&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&lt;h1&gt;MATISSE %1&lt;/h1&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td colspan=&quot;2&quot;&gt;&lt;em&gt;Support technique:&lt;/em&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;tr&gt;&lt;td&gt;Tél.:&lt;/td&gt;&lt;td&gt;+33(0)4 94 30 44 35&lt;/td&gt;&lt;/tr&gt;			&lt;tr&gt;&lt;td&gt;Courriel:&lt;/td&gt;&lt;td&gt;&lt;a href=&quot;mailto:aurelien.arnaubec@ifremer.fr&quot;&gt;aurelien.arnaubec@ifremer.fr&lt;/a&gt;&lt;/td&gt;&lt;/tr&gt;
&lt;/table&gt; 
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/AboutDialog.ui" line="138"/>
        <source>Fermer</source>
        <translation type="unfinished">Close</translation>
    </message>
</context>
<context>
    <name>AssemblyDialog</name>
    <message>
        <source>Sauvegarde de l&apos;assemblage...</source>
        <translation type="obsolete">Save Chain...</translation>
    </message>
    <message>
        <source>Nom:</source>
        <translation type="obsolete">Name:</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="obsolete">Version:</translation>
    </message>
    <message>
        <source>Valid:</source>
        <oldsource>Valide</oldsource>
        <translation type="obsolete">Valid:</translation>
    </message>
    <message>
        <source>Author</source>
        <oldsource>Auteur:</oldsource>
        <translation type="obsolete">Author:</translation>
    </message>
    <message>
        <source>Comments:</source>
        <oldsource>Commentaires:</oldsource>
        <translation type="obsolete">Comment:</translation>
    </message>
    <message>
        <source>Enregistrer</source>
        <translation type="obsolete">Save</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="20"/>
        <source>Nouvelle chaine de traitement...</source>
        <oldsource>Nouvelle chaîne de traitement...</oldsource>
        <translation>New processing chain...</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="47"/>
        <source>Nom :</source>
        <translation>Name :</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="86"/>
        <source>Utilisation :</source>
        <translation>Use :</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="117"/>
        <source>Depouillement</source>
        <oldsource>Dépouillement</oldsource>
        <translation>Deferred time</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="133"/>
        <source>Temps reel</source>
        <oldsource>Temps réel</oldsource>
        <translation>Real time</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="157"/>
        <source>Version :</source>
        <translation>Version :</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="190"/>
        <source>Valide :</source>
        <translation>Valid :</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="236"/>
        <source>Auteur :</source>
        <translation>Author :</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="257"/>
        <source>Commentaires :</source>
        <translation>Comments :</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="284"/>
        <source>Creer</source>
        <oldsource>Créer</oldsource>
        <translation>Create</translation>
    </message>
    <message>
        <location filename="ui/AssemblyDialog.ui" line="304"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>AssemblyGui</name>
    <message>
        <location filename="ui/AssemblyGui.ui" line="26"/>
        <source>Matisse 3</source>
        <translation>Matisse 3</translation>
    </message>
    <message>
        <location filename="ui/AssemblyGui.ui" line="326"/>
        <source>Commentaire</source>
        <translation>Comment</translation>
    </message>
    <message>
        <location filename="ui/AssemblyGui.ui" line="410"/>
        <source>Valeur</source>
        <translation>Value</translation>
    </message>
    <message>
        <location filename="ui/AssemblyGui.ui" line="437"/>
        <source>Cartographie</source>
        <translation>Map</translation>
    </message>
    <message>
        <location filename="ui/AssemblyGui.ui" line="570"/>
        <source>Sources</source>
        <translation>Sources</translation>
    </message>
    <message>
        <location filename="ui/AssemblyGui.ui" line="668"/>
        <source>Processeurs</source>
        <translation>Processors</translation>
    </message>
    <message>
        <location filename="ui/AssemblyGui.ui" line="766"/>
        <source>Destination</source>
        <translation>Destination</translation>
    </message>
    <message>
        <location filename="ui/AssemblyGui.ui" line="990"/>
        <source>Deplier la fenetre de parametrage</source>
        <translation>Unfold parameter window</translation>
    </message>
    <message>
        <source>Parametres</source>
        <translation type="obsolete">Parameters sets</translation>
    </message>
    <message>
        <source>Delete processing chain</source>
        <translation type="obsolete">Delete processing chain</translation>
    </message>
    <message>
        <source>Supprimer l&apos;assemblage</source>
        <translation type="obsolete">Delete processing chain</translation>
    </message>
    <message>
        <source>Nouvel assemblage</source>
        <translation type="obsolete">New processing chain</translation>
    </message>
    <message>
        <source>Sauvegarder le travail</source>
        <translation type="obsolete">Save Job</translation>
    </message>
    <message>
        <source>Sauvegarder le travail sous...</source>
        <translation type="obsolete">Save Job As...</translation>
    </message>
    <message>
        <source>Change user/expert mode</source>
        <oldsource>Mode user/expert</oldsource>
        <translation type="obsolete">Change user/expert mode</translation>
    </message>
    <message>
        <source>Lancer un travail</source>
        <translation type="obsolete">Process Job</translation>
    </message>
    <message>
        <source>Lancer un travail </source>
        <translation type="obsolete">Process Job</translation>
    </message>
    <message>
        <source>Recharger les assemblages/travaux</source>
        <translation type="obsolete">Reload chains/jobs</translation>
    </message>
    <message>
        <source>Recharger les assemblages/travaux...</source>
        <translation type="obsolete">Reload chains/jobs...</translation>
    </message>
    <message>
        <source>Save parameters set</source>
        <oldsource>Sauvegarder les paramètres</oldsource>
        <translation type="obsolete">Save parameters set</translation>
    </message>
    <message>
        <source>Sauvegarder l&apos;assemblage</source>
        <translation type="obsolete">Save processing chain</translation>
    </message>
    <message>
        <source>Sauvegarder l&apos;assemblage sous...</source>
        <translation type="obsolete">Save processing chain as...</translation>
    </message>
    <message>
        <source>Supprimer le travail</source>
        <translation type="obsolete">Delete Job</translation>
    </message>
    <message>
        <source>Stopper l&apos;exécution travail</source>
        <translation type="obsolete">Stop Job</translation>
    </message>
    <message>
        <source>Supprimer les Paramètres</source>
        <translation type="obsolete">Delete parameters set</translation>
    </message>
</context>
<context>
    <name>DuplicateDialog</name>
    <message>
        <location filename="ui/DuplicateDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/DuplicateDialog.ui" line="22"/>
        <source>Saisir un nouveau nom :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/DuplicateDialog.ui" line="49"/>
        <source>Dupliquer</source>
        <translation type="unfinished">Duplicate</translation>
    </message>
    <message>
        <location filename="ui/DuplicateDialog.ui" line="69"/>
        <source>Annuler</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>ExpertFormWidget</name>
    <message>
        <location filename="ui/ExpertFormWidget.ui" line="32"/>
        <source>Form</source>
        <translation>Form</translation>
    </message>
    <message>
        <source>Parametres courants</source>
        <oldsource>Paramètres courants</oldsource>
        <translation type="obsolete">Algorithm parameters</translation>
    </message>
    <message>
        <source>Parametres</source>
        <oldsource>Paramètres</oldsource>
        <translation type="obsolete">Parameters sets</translation>
    </message>
    <message>
        <source>Sources</source>
        <translation type="obsolete">Sources</translation>
    </message>
    <message>
        <source>Processeurs</source>
        <translation type="obsolete">Processors</translation>
    </message>
    <message>
        <source>Destinations</source>
        <translation type="obsolete">Destinations</translation>
    </message>
</context>
<context>
    <name>HomeWidget</name>
    <message>
        <location filename="ui/HomeWidget.ui" line="68"/>
        <source>Retour a l&apos;ecran d&apos;accueil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/HomeWidget.ui" line="71"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JobDialog</name>
    <message>
        <source>Sauvegarde du travail</source>
        <translation type="obsolete">Save Job</translation>
    </message>
    <message>
        <location filename="ui/JobDialog.ui" line="53"/>
        <source>Nom :</source>
        <oldsource>Nom:</oldsource>
        <translation>Name :</translation>
    </message>
    <message>
        <source>Commentaires:</source>
        <translation type="obsolete">Comments:</translation>
    </message>
    <message>
        <location filename="ui/JobDialog.ui" line="20"/>
        <source>Nouvelle tache</source>
        <oldsource>Nouvelle tâche</oldsource>
        <translation>New task</translation>
    </message>
    <message>
        <location filename="ui/JobDialog.ui" line="83"/>
        <source>Commentaires :</source>
        <translation>Comments :</translation>
    </message>
    <message>
        <location filename="ui/JobDialog.ui" line="129"/>
        <source>Chemin du resultat :</source>
        <oldsource>Chemin du résultat :</oldsource>
        <translation>Result path :</translation>
    </message>
    <message>
        <location filename="ui/JobDialog.ui" line="136"/>
        <source>Prefixe du fichier de sortie :</source>
        <oldsource>Fichier de sortie :</oldsource>
        <translation type="unfinished">Output file :</translation>
    </message>
    <message>
        <location filename="ui/JobDialog.ui" line="143"/>
        <source>Fichier de navigation :</source>
        <translation>Navigation file :</translation>
    </message>
    <message>
        <location filename="ui/JobDialog.ui" line="153"/>
        <source>Chemin des donnees :</source>
        <oldsource>Chemin des données :</oldsource>
        <translation>Data path :</translation>
    </message>
    <message>
        <location filename="ui/JobDialog.ui" line="240"/>
        <source>Enregistrer</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="ui/JobDialog.ui" line="260"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>MatisseServer::AssemblyDialog</name>
    <message>
        <location filename="src/AssemblyDialog.cpp" line="33"/>
        <source>Nouvelle chaine de traitement...</source>
        <oldsource>Nouvelle cha�ne de traitement...</oldsource>
        <translation>New processing chain...</translation>
    </message>
    <message>
        <location filename="src/AssemblyDialog.cpp" line="42"/>
        <source>Creer</source>
        <oldsource>Cr�er</oldsource>
        <translation>Create</translation>
    </message>
    <message>
        <location filename="src/AssemblyDialog.cpp" line="45"/>
        <source>Enregistrer la chaine de traitement...</source>
        <oldsource>Enregistrer la cha�ne de traitement...</oldsource>
        <translation>Save processing chain...</translation>
    </message>
    <message>
        <location filename="src/AssemblyDialog.cpp" line="53"/>
        <source>Enregistrer</source>
        <translation>Save</translation>
    </message>
</context>
<context>
    <name>MatisseServer::AssemblyGraphicsScene</name>
    <message>
        <location filename="src/AssemblyGraphicsScene.cpp" line="170"/>
        <source>Supprimer</source>
        <translation>Delete</translation>
    </message>
    <message>
        <source>Supprimer les sources</source>
        <translation type="obsolete">Delete sources</translation>
    </message>
    <message>
        <source>Supprimer les destinations</source>
        <translation type="obsolete">Delete destinations</translation>
    </message>
    <message>
        <location filename="src/AssemblyGraphicsScene.cpp" line="745"/>
        <source>Assemblage invalide</source>
        <translation>Invalid processing chain</translation>
    </message>
    <message>
        <source>L&apos;assemblage ne peut être chargé...</source>
        <translation type="obsolete">Processing could not be loaded...</translation>
    </message>
    <message>
        <location filename="src/AssemblyGraphicsScene.cpp" line="174"/>
        <source>Supprimer les connexions entrantes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGraphicsScene.cpp" line="177"/>
        <source>Supprimer les connexions sortantes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGraphicsScene.cpp" line="745"/>
        <source>L&apos;assemblage ne peut etre charge...</source>
        <translation>Processing chain could not be loaded...</translation>
    </message>
    <message>
        <location filename="src/AssemblyGraphicsScene.cpp" line="757"/>
        <source>L&apos;assemblage sera partiellement charge...
Continuer ?</source>
        <oldsource>L&apos;assemblage sera partiellement charge...
Continuer?</oldsource>
        <translation>Processing chain will be incomplete...
Do you still want to load it ?</translation>
    </message>
    <message>
        <location filename="src/AssemblyGraphicsScene.cpp" line="779"/>
        <source>Source invalide</source>
        <translation>Invalid source</translation>
    </message>
    <message>
        <location filename="src/AssemblyGraphicsScene.cpp" line="817"/>
        <source>Processeur invalide</source>
        <translation>Invalid processor</translation>
    </message>
    <message>
        <location filename="src/AssemblyGraphicsScene.cpp" line="848"/>
        <source>Destination invalide</source>
        <translation>Invalid destination</translation>
    </message>
</context>
<context>
    <name>MatisseServer::AssemblyGui</name>
    <message>
        <source>Fichier de configuration introuvable</source>
        <translation type="obsolete">Cannot find configuration file</translation>
    </message>
    <message>
        <source>Fichier de configuration illisible</source>
        <translation type="obsolete">Cannot read configuration file</translation>
    </message>
    <message>
        <source>Fichier de configuration incorrect</source>
        <translation type="obsolete">Invalid configuration file</translation>
    </message>
    <message>
        <source>La valeur de XmlRootDir ne peut etre determinee.
Relancez l&apos;application avec un parametre XmlRootDir valide
dans le fichier de configuration!</source>
        <oldsource>La valeur de XmlRootDir ne peut être determinee.
Relancez l&apos;application avec un parametre XmlRootDir valide
dans le fichier de configuration!</oldsource>
        <translation type="obsolete">The XmlRootDir value is unknown.
Relaunch with a valid XmlRootDir value!</translation>
    </message>
    <message>
        <source>Impossible de trouver le fichier:
%1
Relancez l&apos;application avec un nom de fichier valide en parametre
ou un fichier %2 valide!</source>
        <oldsource>Impossible de trouver le fichier:
%1
Relancez l&apos;application avec un nom de fichier valide en paramètre
ou un fichier %2 valide!</oldsource>
        <translation type="obsolete">Cannot find file:
%1
Relaunch with a valid file or a valid %2 file!
</translation>
    </message>
    <message>
        <source>Impossible de lire le fichier:
%1
Relancez l&apos;application avec un nom de fichier valide en parametre
ou un fichier %2 valide!</source>
        <oldsource>Impossible de lire le fichier:
%1
Relancez l&apos;application avec un nom de fichier valide en paramètre
ou un fichier %2 valide!</oldsource>
        <translation type="obsolete">Cannot read file:
%1
Relaunch with a valid file or a valid %2 file!</translation>
    </message>
    <message>
        <source>Auteur</source>
        <translation type="obsolete">Author</translation>
    </message>
    <message>
        <source>Commentaires</source>
        <translation type="obsolete">Comments</translation>
    </message>
    <message>
        <source>Processeur n°%1</source>
        <translation type="obsolete">Processor n°%1</translation>
    </message>
    <message>
        <source>Suppression de jeu de parametres</source>
        <oldsource>Suppression de jeu de paramètres</oldsource>
        <translation type="obsolete">Delete parameters set</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2383"/>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <source>Date de creation:</source>
        <oldsource>Date de création:</oldsource>
        <translation type="obsolete">Creation Date:</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2389"/>
        <source>Auteur:</source>
        <translation>Author:</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2392"/>
        <location filename="src/AssemblyGui.cpp" line="2512"/>
        <source>Commentaire:</source>
        <translation>Comments:</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2531"/>
        <source>Date d&apos;execution:</source>
        <oldsource>Date d&apos;exécution:</oldsource>
        <translation>Execution date:</translation>
    </message>
    <message>
        <source>le dd/MM/yyyy à HH:mm</source>
        <translation type="obsolete">on yyyy/MM/dd at HH:mm</translation>
    </message>
    <message>
        <source>Image resultat:</source>
        <oldsource>Image résultat:</oldsource>
        <translation type="obsolete">Output Image:</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2670"/>
        <source>Supprimer l&apos;assemblage</source>
        <translation>Delete processing chain</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2670"/>
        <source>Voulez vous supprimer l&apos;assemblage %1 ?</source>
        <translation>Confirm suppression of chain processing %1 ?</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2855"/>
        <location filename="src/AssemblyGui.cpp" line="3573"/>
        <source>Travail execute...</source>
        <oldsource>Travail exécuté...</oldsource>
        <translation>Job already processed...</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2856"/>
        <source>Le travail a deja ete execute.
Voulez-vous l&apos;ecraser ?</source>
        <oldsource>Le travail a deje ete execute.
Voulez-vous l&apos;ecraser ?</oldsource>
        <translation>This job was already processed.
Do you want to overwrite it ?</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2881"/>
        <source>Fichier de travail...</source>
        <translation>Job file...</translation>
    </message>
    <message>
        <source>Le fichier %1 n&apos;a pu être écrit...</source>
        <translation type="obsolete">Job file %1 could not be wirtten...</translation>
    </message>
    <message>
        <source>Fichier d&apos;assemblage...</source>
        <translation type="obsolete">Processing chain file...</translation>
    </message>
    <message>
        <source>Le fichier %1 n&apos;est pas valide ou est illisible...</source>
        <translation type="obsolete">File %1 is not valid ou is unreadable...</translation>
    </message>
    <message>
        <source>Le fichier %1 n&apos;est pas pu être écrit...</source>
        <translation type="obsolete">File %1 could not be written...</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2912"/>
        <source>Supprimer le travail</source>
        <translation>Delete Job</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2912"/>
        <source>Voulez vous supprimer le travail %1?</source>
        <translation>Confirm suppression of job %1 ? </translation>
    </message>
    <message>
        <source>Assemblages/parametres modifies...</source>
        <oldsource>Assemblages/paramètres modifiés...</oldsource>
        <translation type="obsolete">Chains/Parameters has changed...</translation>
    </message>
    <message>
        <source>Voulez-vous continuer sans sauvegarder?</source>
        <translation type="obsolete">Continue without saving?</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2881"/>
        <source>Le fichier %1 n&apos;a pu etre ecrit...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3159"/>
        <source>Configurer les parametres de l&apos;application</source>
        <translation>Configure application parameters</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3176"/>
        <source>Creer une nouvelle tache</source>
        <oldsource>Cr�er une nouvelle t�che</oldsource>
        <translation>Create new task</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3177"/>
        <source>Importer une nouvelle tache</source>
        <oldsource>Importer une nouvelle t�che</oldsource>
        <translation>Import new task</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3179"/>
        <source>Supprimer la chaine de traitement</source>
        <oldsource>Supprimer la cha�ne de traitement</oldsource>
        <translation>Delete processing chain</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3181"/>
        <source>Mettre a jour les proprietes</source>
        <oldsource>Mettre � jour les propri�t�s</oldsource>
        <translation>Update properties</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3184"/>
        <source>Executer</source>
        <oldsource>Ex�cuter</oldsource>
        <translation>Execute</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3190"/>
        <source>Ouvrir emplacement du resultat</source>
        <oldsource>Ouvrir emplacement du r�sultat</oldsource>
        <translation>Open result location</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3446"/>
        <source>Vue : Creation</source>
        <oldsource>Vue : Cr�ation</oldsource>
        <translation>View : Creation</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3574"/>
        <source>Le travail a deja ete execute.
Voulez-vous le relancer?</source>
        <translation>This job was already processed.
Do you want to process it again ?</translation>
    </message>
    <message>
        <source>Le travail a déjà été exécuté.
Voulez-vous le relancer?</source>
        <translation type="obsolete">This job was already processed. Do you want to process it again?</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3140"/>
        <source>FICHIER</source>
        <translation>FILE</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3141"/>
        <source>Exporter la vue carto en image</source>
        <translation>Export map view as image</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3142"/>
        <source>Exporter le projet en fichier QGIS</source>
        <translation>Export project as QGIS file</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3143"/>
        <source>Fermer</source>
        <translation>Close</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3146"/>
        <source>AFFICHAGE</source>
        <translation>DISPLAY</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3147"/>
        <source>Mode jour/nuit</source>
        <translation>Mode day/night</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3148"/>
        <source>Barres d&apos;outils</source>
        <translation>Toolbar</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3151"/>
        <source>TRAITEMENTS</source>
        <translation>PROCESSORS</translation>
    </message>
    <message>
        <source>Créer</source>
        <translation type="obsolete">Create</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3153"/>
        <location filename="src/AssemblyGui.cpp" line="3185"/>
        <source>Enregistrer</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3154"/>
        <source>Importer</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3155"/>
        <location filename="src/AssemblyGui.cpp" line="3187"/>
        <source>Exporter</source>
        <translation>Export</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3158"/>
        <source>OUTILS</source>
        <translation>TOOLS</translation>
    </message>
    <message>
        <source>Configurer les paramètres de l&apos;application</source>
        <translation type="obsolete">Configure application parameters</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3160"/>
        <source>Lancer outil rognage et correction d&apos;illumination</source>
        <translation>Launch croping and illumination correction tool </translation>
    </message>
    <message>
        <source>Lancer outil transformation de vidéos en jeux d&apos;image</source>
        <translation type="obsolete">Launch video-to-images conversion tool</translation>
    </message>
    <message>
        <source>Vérifier réception réseau</source>
        <translation type="obsolete">Check network reception</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3166"/>
        <source>Charger un shapefile</source>
        <translation>Load a shapefile</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3167"/>
        <source>Charger un raster</source>
        <translation>Load a raster</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3165"/>
        <source>Cartographie</source>
        <translation>Map</translation>
    </message>
    <message>
        <source>le dd/MM/yyyy a HH:mm</source>
        <translation type="obsolete">on dd/MM/yyyy at HH:mm</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3152"/>
        <source>Creer</source>
        <oldsource>Cr�er</oldsource>
        <translation>Create</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3161"/>
        <source>Lancer outil transformation de videos en jeux d&apos;image</source>
        <oldsource>Lancer outil transformation de vid�os en jeux d&apos;image</oldsource>
        <translation>Launch video-to-images conversion tool</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3162"/>
        <source>Verifier reception reseau</source>
        <oldsource>V�rifier r�ception r�seau</oldsource>
        <translation>Check network reception</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3170"/>
        <source>AIDE</source>
        <translation>HELP</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3171"/>
        <source>Manuel utilisateur</source>
        <translation>User manual</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3172"/>
        <source>A propos</source>
        <translation>About</translation>
    </message>
    <message>
        <source>Créer une nouvelle tâche</source>
        <translation type="obsolete">Create new job</translation>
    </message>
    <message>
        <source>Importer une nouvelle tâche</source>
        <translation type="obsolete">Import new task</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3178"/>
        <location filename="src/AssemblyGui.cpp" line="3186"/>
        <source>Dupliquer</source>
        <translation>Duplicate</translation>
    </message>
    <message>
        <source>Supprimer la chaîne de traitement</source>
        <translation type="obsolete">Remove processing chain</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3180"/>
        <source>Restaurer</source>
        <translation>Restore</translation>
    </message>
    <message>
        <source>Mettre à jour les propriétés</source>
        <translation type="obsolete">Update properties</translation>
    </message>
    <message>
        <source>Exécuter</source>
        <translation type="obsolete">Execute</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3188"/>
        <source>Supprimer</source>
        <translation>Delete</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3189"/>
        <source>Archiver</source>
        <translation>Archive</translation>
    </message>
    <message>
        <source>Ouvrir emplacement du résultat</source>
        <translation type="obsolete">Open result location</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="727"/>
        <source>Mode : Temps reel</source>
        <oldsource>Mode : Temps réel</oldsource>
        <translation>Mode : Real time</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="729"/>
        <source>Mode : Depouillement</source>
        <oldsource>Mode : Dépouillement</oldsource>
        <translation>Mode : Deferred time</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="737"/>
        <location filename="src/AssemblyGui.cpp" line="3480"/>
        <source>Vue : Cartographie</source>
        <translation>View : Map</translation>
    </message>
    <message>
        <source>Vue : Création</source>
        <translation type="obsolete">View : Creation</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="854"/>
        <location filename="src/AssemblyGui.cpp" line="3584"/>
        <source>Modification de parametres...</source>
        <oldsource>Modification de paramètres...</oldsource>
        <translation>Parameters changed...</translation>
    </message>
    <message>
        <source>Un ou plusieurs parametres ont ete modifies.
Voulez-vous enregistrer le travail sous un autre nom?</source>
        <oldsource>Un ou plusieurs paramètres ont été modifiés.
Voulez-vous enregistrer le travail sous un autre nom?</oldsource>
        <translation type="obsolete">At least one parameter has been changed.
Do you want to save the job as a new job ?</translation>
    </message>
    <message>
        <source>Travail annule...</source>
        <oldsource>Travail annulé...</oldsource>
        <translation type="obsolete">Job cancelled...</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3605"/>
        <source>Erreur sur l&apos;assemblage</source>
        <translation>Processing chain in error</translation>
    </message>
    <message>
        <source>Erreur d&apos;ecriture.</source>
        <oldsource>Erreur d&apos;écriture.</oldsource>
        <translation type="obsolete">Write error.</translation>
    </message>
    <message>
        <source>Le fichier de travail %1 n&apos;a pu etre ecrit</source>
        <oldsource>Le fichier de travail %1 n&apos;a pu être ecrit</oldsource>
        <translation type="obsolete">Job file %1 could not be written</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3650"/>
        <source>Travail %1 en cours...</source>
        <translation>Job %1 in progress...</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3662"/>
        <source>Erreur %1: %2</source>
        <translation>Error: %1: %2</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3615"/>
        <source>Fichier introuvable.</source>
        <translation>File not found.</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="761"/>
        <source>Nouvel assemblage...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="762"/>
        <source>L&apos;assemblage &apos;%1&apos; n&apos;a pas encore ete enregistre.
Continuer sans enregistrer ?
(Supprimera le nouvel assemblage)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="782"/>
        <source>Assemblage modifie...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="782"/>
        <source>L&apos;assemblage &apos;%1&apos; a ete modifie.
Continuer sans enregistrer les modifications ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="854"/>
        <source>Les parametres de la tache &apos;%1&apos; ont ete modifies.
Enregistrer les modifications avant de continuer ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1021"/>
        <source>Manuel Utilisateur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1021"/>
        <source>Le fichier du manuel utilisateur &apos;%1&apos; n&apos;existe pas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1122"/>
        <location filename="src/AssemblyGui.cpp" line="2665"/>
        <source>Chemin introuvable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1122"/>
        <source>Le chemin parametre comme emplacement du resultat &apos;%1&apos; n&apos;existe pas.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1143"/>
        <source>Archivage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1143"/>
        <source>La tache &apos;%1&apos; a bien ete archivee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1150"/>
        <source>Echec archivage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1150"/>
        <source>La tache &apos;%1&apos; n&apos;a pas pu etre archivee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1206"/>
        <source>Duplication de tache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1206"/>
        <source>La tache &apos;%1&apos; a bien ete dupliquee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1209"/>
        <location filename="src/AssemblyGui.cpp" line="1241"/>
        <source>Echec duplication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1209"/>
        <source>La tache &apos;%1&apos; n&apos;a pas pu etre dupliquee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1238"/>
        <source>Duplication de traitement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1238"/>
        <source>La chaine de traitement &apos;%1&apos; a bien ete dupliquee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1241"/>
        <source>La chaine de traitement &apos;%1&apos; n&apos;a pas pu etre dupliquee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1281"/>
        <source>Export de la vue cartographie en image...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1281"/>
        <source>Fichier image (*.png)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1292"/>
        <source>Export de la vue carto en image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1293"/>
        <source>La vue cartographique a bien ete exportee dans le fichier image %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1302"/>
        <source>Export du projet QGIS...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1302"/>
        <source>Fichier projet (*.qgs)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1313"/>
        <source>Export du projet QGIS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1314"/>
        <source>La vue cartographique a bien ete exportee sous forme de projet QGIS dans le fichier %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1319"/>
        <source>Ouverture fichier shapefile...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1319"/>
        <source>Fichier shapefile (*.shp)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1331"/>
        <source>Ouverture fichier raster...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1331"/>
        <source>Fichier raster (*.tif *.tiff)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1346"/>
        <location filename="src/AssemblyGui.cpp" line="1368"/>
        <source>Configuration systeme incomplete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1346"/>
        <source>L&apos;outil de correction d&apos;illumination n&apos;est pas defini dans la configuration systeme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1355"/>
        <location filename="src/AssemblyGui.cpp" line="1377"/>
        <source>Outil non trouve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1355"/>
        <source>Impossible de trouver le fichier executable de l&apos;outil de correction d&apos;illumination &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1368"/>
        <source>L&apos;outil de transformation de video en image n&apos;est pas defini dans la configuration systeme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1377"/>
        <source>Impossible de trouver le fichier executable de l&apos;outil de transformation de video en image &apos;%1&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1410"/>
        <source>Echec de l&apos;export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1411"/>
        <source>Aucune tache n&apos;est selectionnee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1411"/>
        <source>Aucune chaine de traitement n&apos;est selectionnee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1412"/>
        <source>Export d&apos;une tache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1412"/>
        <source>Export d&apos;une chaine de traitement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1413"/>
        <source>La tache &apos;%1&apos; a bien ete exportee dans &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1413"/>
        <source>La chaine de traitement &apos;%1&apos; a bien ete exportee dans &apos;%2&apos;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1414"/>
        <location filename="src/AssemblyGui.cpp" line="1592"/>
        <source>L&apos;operation a echoue.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1456"/>
        <source>Le fichier de la tache &apos;%1&apos; n&apos;existe pas.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1465"/>
        <source>Le fichier de parametrage de la tache &apos;%1&apos; n&apos;existe pas.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1477"/>
        <source>Impossible de charger l&apos;assemblage &apos;%1&apos; parent de la tache &apos;%2&apos;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1491"/>
        <source>Le fichier d&apos;assemblage&apos; &apos;%1&apos; n&apos;existe pas.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1544"/>
        <source>Importer une tache...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1544"/>
        <source>Importer un assemblage...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1545"/>
        <source>Fichier export (*.zip)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1588"/>
        <source>Echec de l&apos;import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1589"/>
        <source>Import d&apos;une tache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1589"/>
        <source>Import d&apos;une chaine de traitement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1590"/>
        <source>Etes-vous sur de vouloir continuer ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1591"/>
        <source>Etes-vous sur de vouloir l&apos;ecraser ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1593"/>
        <source>L&apos;operation a temporairement echoue.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1594"/>
        <source>Reessayer ulterieurement.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1595"/>
        <source>Supprimer le fichier manuellement ou reessayer ulterieurement.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1634"/>
        <source>Le fichier que vous essayez d&apos;importer ne contient pas de fichier de definition d&apos;une tache.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1640"/>
        <source>Le fichier que vous essayez d&apos;importer ne contient pas de fichier de parametrage de la tache.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1647"/>
        <source>Le fichier que vous essayez d&apos;importer ne contient pas de fichier de definition d&apos;une chaine de traitement.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1653"/>
        <source>Le fichier que vous essayez d&apos;importer ne contient pas de fichier de parametrage d&apos;une chaine de traitement.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1659"/>
        <source>Le fichier que vous essayez d&apos;importer ne contient pas d&apos;information sur la plateforme a l&apos;origine de l&apos;export.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1679"/>
        <source>Impossible d&apos;extraire le contenu de l&apos;archive &apos;%1&apos;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1689"/>
        <source>Le fichier d&apos;import est invalide.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1696"/>
        <source>Aucune information n&apos;est disponible sur la plateforme distante.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1708"/>
        <source>Les versions de Matisse distante et locale n&apos;ont pas pu etre comparees.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1711"/>
        <source>L&apos;archive a ete exportee a partir d&apos;une version de Matisse plus recente.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1717"/>
        <source>Vous essayez d&apos;importer une archive exportee a partir d&apos;une version plus ancienne de Matisse.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1742"/>
        <source>Vous essayez d&apos;importer une archive exportee a partir d&apos;une plateforme differente (voir ci-dessous).
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1785"/>
        <source>Le fichier de tache contenu dans l&apos;archive est invalide.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1810"/>
        <source>La tache que vous essayez d&apos;importer ne correspond pas a l&apos;assemblage selectionne.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1856"/>
        <source>La tache %1 existe deja sur ce poste.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1896"/>
        <source>La chaine de traitement %1 contenue dans l&apos;archive est differente de celle presente sur ce poste.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1915"/>
        <source>Le parametrage de la chaine de traitement %1 contenu dans l&apos;archive est different de celui present sur ce poste.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1931"/>
        <source>La chaine de traitement %1 existe sur ce poste mais n&apos;a pas de fichier de parametrage.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1950"/>
        <source>La chaine de traitement %1 existe deja sur ce poste.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1980"/>
        <source>Impossible de supprimer le fichier de tache existant &apos;%1&apos;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1989"/>
        <source>Impossible de supprimer le fichier de parametrage de tache existant &apos;%1&apos;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="1998"/>
        <source>Impossible de supprimer le fichier de definition d&apos;assemblage existant &apos;%1&apos;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2007"/>
        <source>Impossible de supprimer le fichier de parametrage d&apos;assemblage existant &apos;%1&apos;.
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2022"/>
        <source>Impossible de copier le fichier de definition de la tache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2034"/>
        <source>Impossible de copier le fichier de parametrage de la tache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2046"/>
        <source>Impossible de copier le fichier de definition de la chaine de traitement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2055"/>
        <source>Impossible de copier le fichier de parametrage de la chaine de traitement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2073"/>
        <source>La tache &apos;%1&apos; a bien ete importee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2079"/>
        <source>La chaine de traitement &apos;%1&apos; a bien ete importee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2094"/>
        <source>Replier la fenetre de parametrage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2098"/>
        <source>Deplier la fenetre de parametrage</source>
        <translation type="unfinished">Unfold parameter window</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2144"/>
        <source>Dossier d&apos;archivage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2144"/>
        <source>Le dossier d&apos;archivage &apos;%1&apos; contient deja des taches archivees et ne peut pas etre modifie.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2386"/>
        <source>Date de création:</source>
        <translation>Creation date:</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2532"/>
        <source>dd/MM/yyyy HH:mm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2537"/>
        <source>Images resultat:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="2665"/>
        <source>La chaine de traitement a des taches archivees et ne peut pas etre supprimee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3211"/>
        <source>Agrandir la fenetre principale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3215"/>
        <source>Restaurer la taille initiale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3450"/>
        <source>Basculer sur la vue Cartographie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3484"/>
        <source>Basculer sur la vue Creation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3585"/>
        <source>Un ou plusieurs parametres ont ete modifies.
Voulez-vous enregistrer le parametrage de la tache ?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3616"/>
        <source>Le fichier de travail %1 n&apos;a pu etre lance</source>
        <oldsource>Le fichier de travail %1 n&apos;a pu être lancé</oldsource>
        <translation>Job file %1 could not be processed</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3678"/>
        <source>Arret du travail en cours.</source>
        <oldsource>Arrêt du travail en cours.</oldsource>
        <translation>Stop current job.</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3679"/>
        <source>Voulez vous arreter ou annuler le travail?</source>
        <oldsource>Voulez vous arrêter ou annuler le travail?</oldsource>
        <translation>Do you want to stop current job?</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3683"/>
        <source>Arret</source>
        <oldsource>Arrêt</oldsource>
        <translation>Stop</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3777"/>
        <source>Travail %1 annule...</source>
        <oldsource>Travail %1 annulé...</oldsource>
        <translation>Job %1 cancelled...</translation>
    </message>
    <message>
        <location filename="src/AssemblyGui.cpp" line="3791"/>
        <source>Travail %1 termine...</source>
        <oldsource>Travail %1 terminé...</oldsource>
        <translation>Job %1 finished...</translation>
    </message>
</context>
<context>
    <name>MatisseServer::DuplicateDialog</name>
    <message>
        <location filename="src/DuplicateDialog.cpp" line="38"/>
        <location filename="src/DuplicateDialog.cpp" line="43"/>
        <location filename="src/DuplicateDialog.cpp" line="49"/>
        <location filename="src/DuplicateDialog.cpp" line="51"/>
        <location filename="src/DuplicateDialog.cpp" line="59"/>
        <source>Duplication impossible...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/DuplicateDialog.cpp" line="38"/>
        <source>Un nom doit obligatoirement etre fourni pour la tache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/DuplicateDialog.cpp" line="43"/>
        <source>Le nouveau nom doit obligatoirement etre different du nom de la tache dupliquee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/DuplicateDialog.cpp" line="49"/>
        <source>Le nom de chaine de traitement &apos;%1&apos; est deja utilise.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/DuplicateDialog.cpp" line="51"/>
        <source>Le nom de tache &apos;%1&apos; est deja utilise.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/DuplicateDialog.cpp" line="59"/>
        <source>Le nom &apos;%1&apos; est deja utilise par une tache archivee.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MatisseServer::ExpertFormWidget</name>
    <message>
        <source>Le fichier %1 n&apos;est pas au format attendu.</source>
        <translation type="obsolete">File %1 has unexpected format.</translation>
    </message>
    <message>
        <source>Parametres modifies...</source>
        <oldsource>Paramètres modifiés...</oldsource>
        <translation type="obsolete">Parameters set modified...</translation>
    </message>
    <message>
        <source>Voulez vous enregistrer les parametres?</source>
        <oldsource>Voulez vous enregistrer les paramètres?</oldsource>
        <translation type="obsolete">Do you want to save parameters set?</translation>
    </message>
    <message>
        <source>Fichier modele de parametres</source>
        <oldsource>Fichier modèle de paramètres</oldsource>
        <translation type="obsolete">Parameters model file</translation>
    </message>
    <message>
        <source>Fichier de parametres</source>
        <oldsource>Fichier de paramètres</oldsource>
        <translation type="obsolete">Parameters set file</translation>
    </message>
    <message>
        <source>Parametres courants %1</source>
        <oldsource>Paramètres courants %1</oldsource>
        <translation type="obsolete">Algorithm parameters %1</translation>
    </message>
    <message>
        <source>Paramètres courants </source>
        <translation type="obsolete">Algorithm parameters</translation>
    </message>
</context>
<context>
    <name>MatisseServer::JobDialog</name>
    <message>
        <location filename="src/JobDialog.cpp" line="95"/>
        <location filename="src/JobDialog.cpp" line="101"/>
        <location filename="src/JobDialog.cpp" line="107"/>
        <location filename="src/JobDialog.cpp" line="119"/>
        <source>Enregistrement impossible...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/JobDialog.cpp" line="95"/>
        <source>Un nom doit obligatoirement etre fourni pour la tache.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/JobDialog.cpp" line="102"/>
        <source>Le nom de tache &apos;%1&apos; est deja utilise.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/JobDialog.cpp" line="108"/>
        <source>Le nom &apos;%1&apos; est deja utilise par une tache archivee.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/JobDialog.cpp" line="119"/>
        <source>Le fichier &apos;%1&apos; existe deja.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/JobDialog.cpp" line="148"/>
        <source>Selectionner chemin des donnees</source>
        <oldsource>Sélectionner chemin des données</oldsource>
        <translation>Select data path</translation>
    </message>
    <message>
        <location filename="src/JobDialog.cpp" line="152"/>
        <source>Selectionner chemin du resultat</source>
        <oldsource>Sélectionner chemin du résultat</oldsource>
        <translation>Select result path</translation>
    </message>
    <message>
        <location filename="src/JobDialog.cpp" line="207"/>
        <source>Selectionner fichier de navigation</source>
        <oldsource>Sélectionner fichier de navigation</oldsource>
        <translation>Select navigation file</translation>
    </message>
    <message>
        <source>Creer fichier de sortie</source>
        <oldsource>Créer fichier de sortie</oldsource>
        <translation type="obsolete">Create output file</translation>
    </message>
    <message>
        <source>Fichier sortie mosaique (*.xml)</source>
        <translation type="obsolete">Mosaic output file (*.xml)</translation>
    </message>
</context>
<context>
    <name>MatisseServer::LiveProcessWheel</name>
    <message>
        <location filename="src/LiveProcessWheel.cpp" line="207"/>
        <source>Traitement en cours...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/LiveProcessWheel.cpp" line="218"/>
        <source>Pas de traitement en cours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/LiveProcessWheel.cpp" line="227"/>
        <source>Traitement fige</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MatisseServer::ParametersDialog</name>
    <message>
        <location filename="src/ParametersDialog.cpp" line="92"/>
        <source>Enregistrement impossible</source>
        <translation>Cannot save</translation>
    </message>
    <message>
        <location filename="src/ParametersDialog.cpp" line="95"/>
        <source>Confirmation d&apos;enregistrement</source>
        <translation>Confirm save</translation>
    </message>
    <message>
        <location filename="src/ParametersDialog.cpp" line="96"/>
        <source>Le fichier %1 existe deja.
Voulez vous le remplacer ?</source>
        <oldsource>Le fichier %1 existe deja.
Voulez vous le remplacer?</oldsource>
        <translation type="unfinished">File %1 already exists.
Do you want to replace it?</translation>
    </message>
    <message>
        <location filename="src/ParametersDialog.cpp" line="102"/>
        <source>Le fichier %1 existe deja et ne peut etre ecrase !</source>
        <oldsource>Le fichier %1 existe deja et ne peut etre ecrase!</oldsource>
        <translation type="unfinished">File %1 already exists and can&apos;t be replaced!</translation>
    </message>
    <message>
        <location filename="src/ParametersDialog.cpp" line="107"/>
        <source>Impossible d&apos;ecrire dans le repertoire de sauvegarde !</source>
        <oldsource>Impossible d&apos;ecrire dans le repertoire de sauvegarde!</oldsource>
        <translation type="unfinished">Cannot write in destination directory!</translation>
    </message>
</context>
<context>
    <name>MatisseServer::Server</name>
    <message>
        <source>Fichier de configuration introuvable: %1</source>
        <translation type="obsolete">Cannot find the configuration file: %1</translation>
    </message>
    <message>
        <source>Fichier de configuration illisible: %1</source>
        <translation type="obsolete">Cannot read the configuration file: %1</translation>
    </message>
    <message>
        <source>XmlRootDir introuvable dans le fichier de configuration: %1</source>
        <translation type="obsolete">XmlRootDir has not been found in the config file: %1</translation>
    </message>
    <message>
        <source>DllRootDir introuvable dans le fichier de configuration: %1</source>
        <translation type="obsolete">DllRootDir has not been found in the config file: %1</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="164"/>
        <source>Fichier de parametres introuvable: %1</source>
        <oldsource>Fichier de paramètres introuvable: %1</oldsource>
        <translation>Cannot find parameters file: %1</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="231"/>
        <source>Module source introuvable: %1</source>
        <translation>Cannot find source module: %1</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="239"/>
        <location filename="src/Server.cpp" line="268"/>
        <location filename="src/Server.cpp" line="298"/>
        <source>Parametre requis manquant dans l&apos;assemblage: (%1, %2) pour %3</source>
        <oldsource>Paramètre requis manquant dans l&apos;assemblage: (%1, %2) pour %3</oldsource>
        <translation>Required parameter is missing: (%1,%2) for %3</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="254"/>
        <source>Processeur defini avec un ordre incorrect: %1</source>
        <oldsource>Processeur défini avec un ordre incorrect: %1</oldsource>
        <translation>Invalid order for processor: %1</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="261"/>
        <source>Module processeur introuvable: %1</source>
        <translation>Cannot find processor module: %1</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="280"/>
        <source>Destination non definie</source>
        <oldsource>Destination non définie</oldsource>
        <translation>Undefined destination</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="286"/>
        <source>Destination definie avec un ordre incorrect: %1</source>
        <oldsource>Destination définie avec un ordre incorrect: %1</oldsource>
        <translation>Invalid order for destination: %1</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="292"/>
        <source>Module de destination introuvable: %1</source>
        <translation>Cannot find destination module: %1</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="426"/>
        <source>Fichier de parametres invalide</source>
        <oldsource>Fichier de paramètres invalide</oldsource>
        <translation>Invalid parameters file</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="436"/>
        <source>Impossible de charger l&apos;assemblage %1</source>
        <translation>Unable to load processing chain: %1</translation>
    </message>
    <message>
        <location filename="src/Server.cpp" line="441"/>
        <source>Echec d&apos;execution de l&apos;assemblage</source>
        <translation>Job process failed</translation>
    </message>
</context>
<context>
    <name>MatisseVersionWidget</name>
    <message>
        <location filename="ui/MatisseVersionWidget.ui" line="97"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkCheckDialog</name>
    <message>
        <location filename="ui/NetworkCheckDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/NetworkCheckDialog.ui" line="22"/>
        <source>Saisir le port UDP :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/NetworkCheckDialog.ui" line="51"/>
        <source>Connexion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/NetworkCheckDialog.ui" line="97"/>
        <source>Effacer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/NetworkCheckDialog.ui" line="150"/>
        <source>Fermer</source>
        <translation type="unfinished">Close</translation>
    </message>
    <message>
        <location filename="src/NetworkCheckDialog.cpp" line="36"/>
        <location filename="src/NetworkCheckDialog.cpp" line="45"/>
        <source>Connexion impossible...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/NetworkCheckDialog.cpp" line="36"/>
        <source>Le port saisi est invalide.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/NetworkCheckDialog.cpp" line="45"/>
        <source>Impossible de se connecter sur le port selectionne.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OngoingProcessWidget</name>
    <message>
        <location filename="ui/OngoingProcessWidget.ui" line="97"/>
        <source>Explication sur le traitement en cours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/OngoingProcessWidget.ui" line="168"/>
        <source>Arreter le traitement en cours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/OngoingProcessWidget.ui" line="171"/>
        <location filename="ui/OngoingProcessWidget.ui" line="211"/>
        <location filename="ui/OngoingProcessWidget.ui" line="243"/>
        <location filename="ui/OngoingProcessWidget.ui" line="269"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/OngoingProcessWidget.ui" line="208"/>
        <source>Fermer l&apos;application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/OngoingProcessWidget.ui" line="240"/>
        <source>Agrandir la fenetre principale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/OngoingProcessWidget.ui" line="266"/>
        <source>Reduire la fenetre principale</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParametersDialog</name>
    <message>
        <location filename="ui/ParametersDialog.ui" line="20"/>
        <source>Sauvegarde des paramètres</source>
        <translation>Parameters Save</translation>
    </message>
    <message>
        <location filename="ui/ParametersDialog.ui" line="53"/>
        <source>Version du modèle:</source>
        <translation>Model version:</translation>
    </message>
    <message>
        <location filename="ui/ParametersDialog.ui" line="120"/>
        <source>Nom:</source>
        <translation>Name:</translation>
    </message>
    <message>
        <location filename="ui/ParametersDialog.ui" line="168"/>
        <source>Fichier:</source>
        <translation>File:</translation>
    </message>
    <message>
        <location filename="ui/ParametersDialog.ui" line="175"/>
        <source>filename</source>
        <translation>FileName</translation>
    </message>
    <message>
        <location filename="ui/ParametersDialog.ui" line="217"/>
        <source>Auteur:</source>
        <translation>Author:</translation>
    </message>
    <message>
        <location filename="ui/ParametersDialog.ui" line="244"/>
        <source>Commentaires:</source>
        <translation>Comments:</translation>
    </message>
    <message>
        <location filename="ui/ParametersDialog.ui" line="284"/>
        <source>Enregistrer</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="ui/ParametersDialog.ui" line="291"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="ui/PreferencesDialog.ui" line="14"/>
        <source>Fenetre configuration de l&apos;application</source>
        <oldsource>Fenêtre configuration de l&apos;application</oldsource>
        <translation>Application configuration window</translation>
    </message>
    <message>
        <location filename="ui/PreferencesDialog.ui" line="91"/>
        <source>Langue (EN/FR) :</source>
        <translation>Language (EN/FR) :</translation>
    </message>
    <message>
        <location filename="ui/PreferencesDialog.ui" line="98"/>
        <source>Prefixe nom du fichier mosaique par defaut :</source>
        <oldsource>Préfixe nom du fichier mosaïque par défaut :</oldsource>
        <translation>Default mosaic file name prefix :</translation>
    </message>
    <message>
        <location filename="ui/PreferencesDialog.ui" line="132"/>
        <source>Activation mode programmation :  </source>
        <translation>Programming mode activation :</translation>
    </message>
    <message>
        <location filename="ui/PreferencesDialog.ui" line="142"/>
        <source>Chemin import/export :</source>
        <translation>Import/export path :</translation>
    </message>
    <message>
        <location filename="ui/PreferencesDialog.ui" line="168"/>
        <source>Chemin d&apos;archivage :</source>
        <translation>Archive path :</translation>
    </message>
    <message>
        <location filename="ui/PreferencesDialog.ui" line="191"/>
        <source>Chemin des resultats par defaut :</source>
        <oldsource>Chemin des résultats par défaut :</oldsource>
        <translation>Default results path :</translation>
    </message>
    <message>
        <location filename="ui/PreferencesDialog.ui" line="218"/>
        <source>Enregistrer</source>
        <translation>Save</translation>
    </message>
    <message>
        <location filename="ui/PreferencesDialog.ui" line="238"/>
        <source>Annuler</source>
        <translation>Cancel</translation>
    </message>
</context>
<context>
    <name>RestoreJobsDialog</name>
    <message>
        <location filename="ui/RestoreJobsDialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/RestoreJobsDialog.ui" line="20"/>
        <source>Taches archivees pour l&apos;assemblage %1 :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="ui/RestoreJobsDialog.ui" line="67"/>
        <source>Restaurer</source>
        <translation type="unfinished">Restore</translation>
    </message>
    <message>
        <location filename="ui/RestoreJobsDialog.ui" line="87"/>
        <source>Annuler</source>
        <translation type="unfinished">Cancel</translation>
    </message>
</context>
<context>
    <name>ServerDialog</name>
    <message>
        <location filename="ui/ServerDialog.ui" line="14"/>
        <source>MatisseServer</source>
        <translation></translation>
    </message>
    <message>
        <location filename="ui/ServerDialog.ui" line="23"/>
        <source>Serveur</source>
        <translation>Server</translation>
    </message>
    <message>
        <location filename="ui/ServerDialog.ui" line="45"/>
        <source>Adresse:</source>
        <translation>Address:</translation>
    </message>
    <message>
        <location filename="ui/ServerDialog.ui" line="77"/>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <location filename="ui/ServerDialog.ui" line="119"/>
        <source>Client connecté</source>
        <translation>Connected client</translation>
    </message>
</context>
<context>
    <name>StatusMessageWidget</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Form</translation>
    </message>
    <message>
        <source>Messages:</source>
        <translation type="obsolete">Messages:</translation>
    </message>
    <message>
        <location filename="ui/StatusMessageWidget.ui" line="185"/>
        <source>Effacer la liste de messages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>UserFormWidget</name>
    <message>
        <source>Form</source>
        <translation type="obsolete">Form</translation>
    </message>
    <message>
        <source>Parametres</source>
        <oldsource>Paramètres</oldsource>
        <translation type="obsolete">Parameters sets</translation>
    </message>
    <message>
        <location filename="src/UserFormWidget.cpp" line="32"/>
        <source>Ajustement auto a l&apos;emprise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/UserFormWidget.cpp" line="36"/>
        <source>Suivre le dernier ajout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/UserFormWidget.cpp" line="40"/>
        <source>Deplacement manuel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/UserFormWidget.cpp" line="94"/>
        <source>Deplacer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/UserFormWidget.cpp" line="103"/>
        <source>Zoom AV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/UserFormWidget.cpp" line="112"/>
        <source>Zoom AR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/UserFormWidget.cpp" line="121"/>
        <source>Recentrer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="src/UserFormWidget.cpp" line="152"/>
        <source>Supprimer</source>
        <translation type="unfinished">Delete</translation>
    </message>
</context>
<context>
    <name>VisuModeWidget</name>
    <message>
        <location filename="ui/VisuModeWidget.ui" line="80"/>
        <source>Vue : Cartographie</source>
        <translation>View : Map</translation>
    </message>
</context>
<context>
    <name>WelcomeDialog</name>
    <message>
        <location filename="ui/WelcomeDialog.ui" line="14"/>
        <source>Accueil Matisse</source>
        <translation>Matisse welcome dialog</translation>
    </message>
    <message>
        <location filename="ui/WelcomeDialog.ui" line="56"/>
        <source>CONFIGURATION</source>
        <oldsource>
CONFIGURATION</oldsource>
        <translation type="unfinished">CONFIGURATION</translation>
    </message>
    <message>
        <location filename="ui/WelcomeDialog.ui" line="81"/>
        <source>TEMPS REEL
</source>
        <translation>REAL TIME</translation>
    </message>
    <message>
        <location filename="ui/WelcomeDialog.ui" line="110"/>
        <source>PROGRAMMATION
</source>
        <translation>PROGRAMMING</translation>
    </message>
    <message>
        <location filename="ui/WelcomeDialog.ui" line="130"/>
        <source>DEPOUILLEMENT</source>
        <translation>DEFERRED TIME</translation>
    </message>
    <message>
        <location filename="ui/WelcomeDialog.ui" line="146"/>
        <source>...</source>
        <translation></translation>
    </message>
</context>
</TS>
