#include "MapLayersList.h"

using namespace MatisseServer;

MapLayersList::MapLayersList(QWidget *parent) :
    QListWidget(parent)
{

}

void MapLayersList::dropEvent(QDropEvent *event)
{

}

