#ifndef ABOUTWEBVIEW_H
#define ABOUTWEBVIEW_H

#include <QDialog>
#include <QVBoxLayout>
#include <QWebView>


class AboutWebView : public QDialog
{
public:
    AboutWebView(QWidget* parent);
};

#endif // ABOUTWEBVIEW_H
