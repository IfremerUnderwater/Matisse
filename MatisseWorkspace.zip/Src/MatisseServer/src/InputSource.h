#ifndef INPUTSOURCE_H
#define INPUTSOURCE_H

// ???? je ne sais pas � quoi ca sert???
class InputSource
{
public:
    InputSource() {}
    virtual bool isValid()=0;
};

#endif // INPUTSOURCE_H
