#ifndef MOSAICOPTIMIZER_H
#define MOSAICOPTIMIZER_H

#include "libopticalmapping_global.h"

class LIBOPTICALMAPPINGSHARED_EXPORT MosaicOptimizer
{
public:
    MosaicOptimizer();
};

#endif // MOSAICOPTIMIZER_H
