#include "MosaicOptimizer.h"

MosaicOptimizer::MosaicOptimizer()
{
}
