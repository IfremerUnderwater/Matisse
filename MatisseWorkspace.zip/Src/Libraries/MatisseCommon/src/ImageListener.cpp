﻿#include "ImageListener.h"
using namespace MatisseCommon;

ImageListener::ImageListener(QObject *parent) :
    QObject(parent)
{
}
