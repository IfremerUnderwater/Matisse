#ifndef VIDEOSOURCE_H
#define VIDEOSOURCE_H
#include <QObject>

#include "InputSource.h"


using namespace MatisseCommon;

class VideoSource : public QObject
{
    Q_OBJECT

public:
    VideoSource();

private:
};

#endif // VIDEOSOURCE_H
