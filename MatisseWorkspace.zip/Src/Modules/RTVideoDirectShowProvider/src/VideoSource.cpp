#include "VideoSource.h"

VideoSource::VideoSource()
{

}
