﻿class A
{
    // éssai
public:
    A() {}
};

