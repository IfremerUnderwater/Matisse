<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="26"/>
        <source>Dim2Server</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="93"/>
        <source>Periode (s)</source>
        <translation>Période</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="83"/>
        <source>Port</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="39"/>
        <source>Configure Dim2 Server:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="56"/>
        <source>DIM2 File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="72"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="108"/>
        <source>Dim2UDPServer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="113"/>
        <source>NavPhotoInfoServer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="132"/>
        <source>Start</source>
        <translation>Démarrer</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="57"/>
        <source>Choix d&apos;un fichier...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="76"/>
        <source>Fichier non trouvé :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> load image </source>
        <translation type="obsolete">Charger Image</translation>
    </message>
</context>
</TS>
