<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="26"/>
        <source>Dim2Server</source>
        <translation></translation>
    </message>
    <message>
        <source>Configure</source>
        <translation type="obsolete">Configure</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="93"/>
        <source>Periode (s)</source>
        <translation>period</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="83"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <source>Fichier DIM2</source>
        <translation type="obsolete">DIM2 File</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="39"/>
        <source>Configure Dim2 Server:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="56"/>
        <source>DIM2 File:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="72"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="108"/>
        <source>Dim2UDPServer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="113"/>
        <source>NavPhotoInfoServer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="132"/>
        <source>Start</source>
        <translation>Start</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="57"/>
        <source>Choix d&apos;un fichier...</source>
        <translation>Open File...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="76"/>
        <source>Fichier non trouvé :</source>
        <translation>File not found : </translation>
    </message>
    <message>
        <source>Le fichier n&apos;existe pas:</source>
        <translation type="obsolete">File does not exist:</translation>
    </message>
    <message>
        <source>Le fichier ne peut pas être ouvert:</source>
        <translation type="obsolete">File could not be opened:</translation>
    </message>
    <message>
        <source>Erreur de port.</source>
        <translation type="obsolete">Invalid Port.</translation>
    </message>
    <message>
        <source> load image </source>
        <translation type="obsolete">Load Image</translation>
    </message>
</context>
</TS>
