﻿========================================================================
    QtLoaderApp: Exemple de projet DLL Visual Studio 2010
========================================================================

Cette DLL exporte 3 fonctions:
* init
* doWork
* stop

Elle simule un projet utilisant MATLAB.

Elle est destinée à être appelée depuis un plugin de Matisse.



