﻿========================================================================
    PluginMock: Exemple de projet DLL Qt
========================================================================

Cette DLL implemente ModuleInterface pour appeler une DLL utilisant MATLAB.

Elle est destinée à être chargée depuis MatisseServer ou QtLoaderApp.




